import {NgModule} from "@angular/core";
import {SrcComponent} from "./src.component";
import {BrowserModule} from "@angular/platform-browser";
import {CommonModule} from "@angular/common";


@NgModule({
    imports:[BrowserModule,CommonModule],
    declarations:[SrcComponent],
    bootstrap:[SrcComponent]
})
export class SrcModule
{

}