import {Component} from "@angular/core";

//<commodity-app></commodity-app>
@Component({
    selector:'commodity-app',
    templateUrl:'./src/src.component.html',
    styleUrls:['./src/src.component.css']
})
export class SrcComponent
{
  //field
  private logoPath:string;

  constructor()
  {
      this.logoPath="./src/images/logo.png";
  }


}